
import React, { useState } from 'react';

interface LocationInputProps {
  onLocationSet: (loc: string) => void;
}

const LocationInput: React.FC<LocationInputProps> = ({ onLocationSet }) => {
  const [input, setInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      onLocationSet(input.trim());
    }
  };

  const useCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((pos) => {
        // Mocking address fetch for brevity in this simulation
        onLocationSet(`Current Location (Lat: ${pos.coords.latitude.toFixed(2)}, Lng: ${pos.coords.longitude.toFixed(2)})`);
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-slate-950">
      <div className="w-full max-w-lg">
        <div className="text-center mb-10 space-y-4">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-indigo-600 rounded-2xl shadow-2xl shadow-indigo-500/50 mb-4">
            <i className="fa-solid fa-bolt text-3xl"></i>
          </div>
          <h1 className="text-4xl font-bold tracking-tight">Flow IQ</h1>
          <p className="text-slate-400 text-lg">Smart Urban Intelligence. Start by entering your location.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <i className="fa-solid fa-location-crosshairs absolute left-4 top-1/2 -translate-y-1/2 text-indigo-400"></i>
            <input
              autoFocus
              type="text"
              placeholder="E.g., Bandra West, Mumbai"
              className="w-full bg-slate-900 border-2 border-slate-800 rounded-2xl py-4 pl-12 pr-4 text-lg focus:border-indigo-500 focus:outline-none transition-all placeholder:text-slate-600"
              value={input}
              onChange={(e) => setInput(e.target.value)}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <button
              type="submit"
              className="py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-2xl transition-all shadow-lg shadow-indigo-500/25 flex items-center justify-center gap-2"
            >
              Initialize Analysis <i className="fa-solid fa-arrow-right"></i>
            </button>
            <button
              type="button"
              onClick={useCurrentLocation}
              className="py-4 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-2xl transition-all flex items-center justify-center gap-2"
            >
              <i className="fa-solid fa-compass"></i> GPS Detect
            </button>
          </div>
        </form>

        <div className="mt-12 grid grid-cols-3 gap-4 opacity-50 text-center">
          <div>
            <i className="fa-solid fa-shield-halved text-2xl mb-2"></i>
            <p className="text-[10px] uppercase font-bold tracking-widest">Safe & Secure</p>
          </div>
          <div>
            <i className="fa-solid fa-brain text-2xl mb-2"></i>
            <p className="text-[10px] uppercase font-bold tracking-widest">AI Driven</p>
          </div>
          <div>
            <i className="fa-solid fa-indian-rupee-sign text-2xl mb-2"></i>
            <p className="text-[10px] uppercase font-bold tracking-widest">Localized</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LocationInput;
