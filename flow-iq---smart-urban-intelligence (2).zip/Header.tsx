
import React from 'react';
import { ModuleType } from '../types';

interface HeaderProps {
  location: string;
  currency: string;
  setCurrency: (c: string) => void;
  activeModule: ModuleType;
}

const Header: React.FC<HeaderProps> = ({ location, currency, setCurrency, activeModule }) => {
  return (
    <header className="h-16 px-8 flex items-center justify-between border-b border-white/5 glass sticky top-0 z-30">
      <div className="flex items-center gap-4">
        <h2 className="text-lg font-semibold capitalize text-slate-100">
          {activeModule.toLowerCase().replace('_', ' ')}
        </h2>
        <span className="h-4 w-[1px] bg-slate-700"></span>
        <div className="flex items-center gap-2 text-sm text-slate-400">
          <i className="fa-solid fa-location-dot"></i>
          <span>{location}</span>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <select 
          value={currency} 
          onChange={(e) => setCurrency(e.target.value)}
          className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1 text-sm focus:ring-1 focus:ring-indigo-500 outline-none"
        >
          <option value="INR">INR (₹)</option>
          <option value="USD">USD ($)</option>
          <option value="EUR">EUR (€)</option>
        </select>
        
        <div className="flex items-center gap-3">
          <button className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white transition-colors">
            <i className="fa-solid fa-bell text-xs"></i>
          </button>
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600"></div>
        </div>
      </div>
    </header>
  );
};

export default Header;
