
import React from 'react';
import { ModuleType, HistoryItem } from '../types';
import ScoreDisplay from './ScoreDisplay';

interface DashboardProps {
  location: string;
  history: HistoryItem[];
  onModuleSwitch: (m: ModuleType) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ location, history, onModuleSwitch }) => {
  const latestHistory = history[0];
  
  const modules = [
    { type: ModuleType.TRANSPORT, icon: 'fa-route', title: 'Transport', desc: 'Commute IQ & Traffic' },
    { type: ModuleType.LIVING, icon: 'fa-city', title: 'Living', desc: 'Lifestyle & Stability' },
    { type: ModuleType.INVESTMENT, icon: 'fa-chart-line', title: 'Investment', desc: 'Growth & Real Estate' },
    { type: ModuleType.BUDGET, icon: 'fa-wallet', title: 'Budget', desc: 'Travel Cost Tracking' },
    { type: ModuleType.COMMUTER, icon: 'fa-briefcase', title: 'Commuter', desc: 'Daily Route Impact' },
    { type: ModuleType.RELOCATION, icon: 'fa-truck-ramp-box', title: 'Relocation', desc: 'Simulator & Move' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="flex-[2] glass rounded-3xl p-8 border border-white/5">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold">Urban Intelligence Overview</h2>
              <p className="text-slate-400 mt-1">Status Report for {location}</p>
            </div>
            {latestHistory && (
              <ScoreDisplay score={latestHistory.overallScore} label="Latest Score" size="md" />
            )}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
             {modules.map((m) => (
               <button 
                 key={m.type}
                 onClick={() => onModuleSwitch(m.type)}
                 className="p-6 rounded-2xl bg-white/5 border border-white/5 hover:border-indigo-500/50 hover:bg-indigo-500/5 transition-all text-left group"
               >
                 <div className="w-12 h-12 rounded-xl bg-indigo-600/20 flex items-center justify-center mb-4 group-hover:bg-indigo-600 transition-colors">
                   <i className={`fa-solid ${m.icon} text-indigo-400 group-hover:text-white`}></i>
                 </div>
                 <h4 className="font-bold text-slate-200">{m.title}</h4>
                 <p className="text-xs text-slate-500 mt-1">{m.desc}</p>
               </button>
             ))}
          </div>
        </div>

        <div className="flex-1 glass rounded-3xl p-8 border border-white/5">
          <h3 className="text-xl font-bold mb-6">Activity History</h3>
          <div className="space-y-4">
            {history.length === 0 ? (
              <div className="text-center py-10 opacity-30">
                <i className="fa-solid fa-clock-rotate-left text-4xl mb-3"></i>
                <p className="text-sm">No analysis history yet.</p>
              </div>
            ) : (
              history.map((item) => (
                <div key={item.id} className="flex items-center justify-between p-4 rounded-xl bg-slate-900/50 border border-slate-800">
                  <div className="flex items-center gap-4">
                    <div className={`w-2 h-2 rounded-full ${item.overallScore > 70 ? 'bg-emerald-500' : 'bg-amber-500'}`}></div>
                    <div>
                      <p className="text-sm font-bold text-slate-200">{item.module}</p>
                      <p className="text-[10px] text-slate-500 uppercase tracking-tighter">
                        {new Date(item.timestamp).toLocaleDateString()} • {item.location}
                      </p>
                    </div>
                  </div>
                  <span className="text-indigo-400 font-bold">{item.overallScore}</span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
