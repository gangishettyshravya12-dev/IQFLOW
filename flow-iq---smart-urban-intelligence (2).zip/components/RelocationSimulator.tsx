
import React, { useState } from 'react';
import { ModuleType, AnalysisResponse } from '../types';
import { analyzeUrbanData } from '../geminiService';
import AnalysisResult from './AnalysisResult';

interface RelocationSimulatorProps {
  currentLocation: string;
  onResult: (score: number) => void;
}

const RelocationSimulator: React.FC<RelocationSimulatorProps> = ({ currentLocation, onResult }) => {
  const [newLocation, setNewLocation] = useState('');
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<AnalysisResponse | null>(null);

  const handleSimulate = async () => {
    if (!newLocation) return;
    setLoading(true);
    try {
      const result = await analyzeUrbanData(currentLocation, ModuleType.RELOCATION, { target: newLocation });
      setData(result);
      onResult(result.scores.overall);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-4 mb-2">
        <div className="w-12 h-12 rounded-full bg-purple-600/20 flex items-center justify-center">
          <i className="fa-solid fa-truck-ramp-box text-purple-400"></i>
        </div>
        <div>
          <h2 className="text-2xl font-bold">Smart Relocation Simulator</h2>
          <p className="text-slate-400 text-sm">Compare your current lifestyle with a potential new move</p>
        </div>
      </div>

      <div className="glass rounded-3xl p-8 border border-white/5 max-w-2xl mx-auto">
        <div className="flex flex-col md:flex-row items-center gap-6 mb-8">
          <div className="flex-1 w-full">
            <label className="block text-[10px] text-slate-500 uppercase font-bold mb-2">Current City</label>
            <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-xl text-slate-400 text-sm">
              {currentLocation}
            </div>
          </div>
          <div className="md:mt-6">
            <i className="fa-solid fa-right-left text-indigo-500"></i>
          </div>
          <div className="flex-1 w-full">
            <label className="block text-[10px] text-slate-500 uppercase font-bold mb-2">New Target City</label>
            <input 
              placeholder="e.g. Pune, Maharashtra"
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-4 focus:border-indigo-500 focus:outline-none"
              value={newLocation}
              onChange={(e) => setNewLocation(e.target.value)}
            />
          </div>
        </div>
        <button 
          onClick={handleSimulate}
          disabled={loading || !newLocation}
          className="w-full py-4 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-2xl transition-all shadow-lg shadow-purple-500/25 flex items-center justify-center gap-2"
        >
          {loading ? <i className="fa-solid fa-circle-notch animate-spin"></i> : <i className="fa-solid fa-bolt"></i>}
          Simulate Move Impact
        </button>
      </div>

      {loading && (
        <div className="py-20 flex flex-col items-center justify-center space-y-4">
          <div className="w-12 h-12 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin"></div>
          <p className="text-slate-500 text-sm animate-pulse">Running urban dynamic comparison simulations...</p>
        </div>
      )}

      {data && !loading && <AnalysisResult data={data} title="Relocation Impact Report" />}
    </div>
  );
};

export default RelocationSimulator;
