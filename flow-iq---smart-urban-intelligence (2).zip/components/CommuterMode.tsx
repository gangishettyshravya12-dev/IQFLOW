
import React, { useState, useEffect } from 'react';
import { ModuleType, AnalysisResponse } from '../types';
import { analyzeUrbanData } from '../geminiService';
import AnalysisResult from './AnalysisResult';

interface CommuterModeProps {
  location: string;
  onResult: (score: number) => void;
}

const CommuterMode: React.FC<CommuterModeProps> = ({ location, onResult }) => {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<AnalysisResponse | null>(null);

  useEffect(() => {
    const fetchAnalysis = async () => {
      setLoading(true);
      try {
        const result = await analyzeUrbanData(location, ModuleType.COMMUTER);
        setData(result);
        onResult(result.scores.overall);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchAnalysis();
  }, [location]);

  if (loading) return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center space-y-6">
      <div className="relative">
        <div className="w-20 h-20 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin"></div>
        <i className="fa-solid fa-user-clock absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-indigo-400 animate-pulse"></i>
      </div>
      <p className="text-slate-400 font-medium animate-pulse">Calculating Time-Life Balance Impact...</p>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-2">
        <div className="w-12 h-12 rounded-full bg-indigo-600/20 flex items-center justify-center">
          <i className="fa-solid fa-briefcase text-indigo-400"></i>
        </div>
        <div>
          <h2 className="text-2xl font-bold">Daily Commuter IQ</h2>
          <p className="text-slate-400 text-sm">Productivity and well-being analysis for {location}</p>
        </div>
      </div>
      
      {data && <AnalysisResult data={data} title="Productivity & Life Balance Audit" />}
    </div>
  );
};

export default CommuterMode;
