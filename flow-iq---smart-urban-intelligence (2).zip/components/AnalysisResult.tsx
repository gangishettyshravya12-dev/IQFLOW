
import React from 'react';
import { AnalysisResponse } from '../types';
import ScoreDisplay from './ScoreDisplay';

interface AnalysisResultProps {
  data: AnalysisResponse;
  title: string;
}

const AnalysisResult: React.FC<AnalysisResultProps> = ({ data, title }) => {
  const { scores, insights, details, sources } = data;

  const getLabelColor = (label: string) => {
    switch (label) {
      case 'Excellent': return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50';
      case 'Good': return 'bg-indigo-500/20 text-indigo-400 border-indigo-500/50';
      case 'Moderate': return 'bg-amber-500/20 text-amber-400 border-amber-500/50';
      case 'Needs Improvement': return 'bg-rose-500/20 text-rose-400 border-rose-500/50';
      default: return 'bg-slate-500/20 text-slate-400 border-slate-500/50';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Main Score Card */}
        <div className="flex-[2] glass rounded-3xl p-8 border border-white/5 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-6">
             <span className={`px-4 py-1.5 rounded-full text-xs font-bold border ${getLabelColor(insights.decisionLabel)}`}>
               {insights.decisionLabel}
             </span>
          </div>
          
          <h3 className="text-2xl font-bold mb-8">{title}</h3>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-10">
            <ScoreDisplay score={scores.overall} label="Flow IQ" size="lg" />
            <ScoreDisplay score={scores.commute} label="Commute" size="md" />
            <ScoreDisplay score={scores.safety} label="Safety" size="md" />
            <ScoreDisplay score={scores.costEfficiency} label="Efficiency" size="md" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-5 rounded-2xl bg-emerald-500/5 border border-emerald-500/10">
              <h4 className="text-emerald-400 text-sm font-bold uppercase tracking-wider mb-3 flex items-center gap-2">
                <i className="fa-solid fa-circle-check"></i> Strengths
              </h4>
              <ul className="space-y-2">
                {insights.strengths.map((s, i) => (
                  <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
                    <span className="text-emerald-500 mt-1">•</span> {s}
                  </li>
                ))}
              </ul>
            </div>
            <div className="p-5 rounded-2xl bg-rose-500/5 border border-rose-500/10">
              <h4 className="text-rose-400 text-sm font-bold uppercase tracking-wider mb-3 flex items-center gap-2">
                <i className="fa-solid fa-triangle-exclamation"></i> Weaknesses
              </h4>
              <ul className="space-y-2">
                {insights.weaknesses.map((w, i) => (
                  <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
                    <span className="text-rose-500 mt-1">•</span> {w}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Search Grounding Sources */}
          {sources && sources.length > 0 && (
            <div className="mt-8 pt-6 border-t border-white/5">
              <h4 className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-4 flex items-center gap-2">
                <i className="fa-solid fa-globe text-[10px]"></i> Urban Data Sources
              </h4>
              <div className="flex flex-wrap gap-2">
                {sources.map((source, i) => (
                  <a 
                    key={i} 
                    href={source.uri} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-[10px] text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-3 py-1.5 rounded-full hover:bg-indigo-500/20 transition-all flex items-center gap-2 max-w-[220px]"
                  >
                    <i className="fa-solid fa-link"></i>
                    <span className="truncate">{source.title}</span>
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Secondary Metrics & Insights */}
        <div className="flex-1 space-y-6">
          <div className="glass rounded-3xl p-6 border border-white/5 h-full">
            <h4 className="text-sm font-bold uppercase tracking-widest text-slate-500 mb-6">Detailed Metrics</h4>
            <div className="space-y-6">
              {[
                { label: 'Lifestyle', value: scores.lifestyle, icon: 'fa-heart' },
                { label: 'Growth', value: scores.growthPotential, icon: 'fa-chart-simple' },
                { label: 'Stability', value: scores.livingStability, icon: 'fa-building' },
                { label: 'Stress Impact', value: scores.stressImpact, icon: 'fa-brain' },
                { label: 'Productivity', value: scores.productivity, icon: 'fa-bolt' },
              ].map((item, idx) => (
                <div key={idx} className="space-y-2">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-400 flex items-center gap-2">
                      <i className={`fa-solid ${item.icon} w-4`}></i> {item.label}
                    </span>
                    <span className="font-bold text-slate-200">{Math.round(item.value)}%</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-indigo-500 rounded-full transition-all duration-1000" 
                      style={{ width: `${item.value}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 pt-6 border-t border-white/5">
              <h4 className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-4">AI Recommendations</h4>
              <ul className="space-y-3">
                {insights.suggestions.map((s, i) => (
                  <li key={i} className="text-xs text-slate-400 flex items-start gap-3 bg-white/5 p-3 rounded-xl border border-white/5 hover:border-indigo-500/30 transition-colors">
                    <i className="fa-solid fa-lightbulb text-indigo-400 mt-0.5"></i>
                    {s}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalysisResult;
