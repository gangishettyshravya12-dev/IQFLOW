
import React, { useState, useEffect } from 'react';
import { ModuleType, AnalysisResponse } from '../types';
import { analyzeUrbanData } from '../geminiService';
import AnalysisResult from './AnalysisResult';

interface LivingAnalysisProps {
  location: string;
  onResult: (score: number) => void;
}

const LivingAnalysis: React.FC<LivingAnalysisProps> = ({ location, onResult }) => {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<AnalysisResponse | null>(null);

  useEffect(() => {
    const fetchAnalysis = async () => {
      setLoading(true);
      try {
        const result = await analyzeUrbanData(location, ModuleType.LIVING);
        setData(result);
        onResult(result.scores.overall);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchAnalysis();
  }, [location]);

  if (loading) return <LoadingState text="Scanning Safety, Schools & AQI Data..." />;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-2">
        <div className="w-12 h-12 rounded-full bg-emerald-600/20 flex items-center justify-center">
          <i className="fa-solid fa-city text-emerald-400"></i>
        </div>
        <div>
          <h2 className="text-2xl font-bold">Living & Lifestyle IQ</h2>
          <p className="text-slate-400 text-sm">Evaluating stability and quality of life in {location}</p>
        </div>
      </div>
      
      {data && <AnalysisResult data={data} title="Lifestyle & Stability Audit" />}
    </div>
  );
};

const LoadingState = ({ text }: { text: string }) => (
  <div className="min-h-[60vh] flex flex-col items-center justify-center space-y-6">
    <div className="relative">
      <div className="w-20 h-20 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin"></div>
      <i className="fa-solid fa-house-circle-check absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-emerald-400 animate-pulse"></i>
    </div>
    <p className="text-slate-400 font-medium animate-pulse">{text}</p>
  </div>
);

export default LivingAnalysis;
