
import React from 'react';

interface ScoreDisplayProps {
  score: number;
  label: string;
  size?: 'sm' | 'md' | 'lg';
  color?: string;
}

const ScoreDisplay: React.FC<ScoreDisplayProps> = ({ score, label, size = 'md', color = 'indigo' }) => {
  const radius = size === 'sm' ? 24 : size === 'md' ? 40 : 60;
  const stroke = size === 'sm' ? 4 : size === 'md' ? 8 : 12;
  const normalizedRadius = radius - stroke * 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  const colorClasses = {
    indigo: 'text-indigo-500',
    green: 'text-emerald-500',
    yellow: 'text-amber-500',
    red: 'text-rose-500'
  };

  const activeColor = score > 80 ? 'green' : score > 60 ? 'indigo' : score > 40 ? 'yellow' : 'red';

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative inline-flex items-center justify-center">
        <svg height={radius * 2} width={radius * 2} className="transform -rotate-90">
          <circle
            stroke="currentColor"
            fill="transparent"
            strokeWidth={stroke}
            className="text-slate-800"
            r={normalizedRadius}
            cx={radius}
            cy={radius}
          />
          <circle
            stroke="currentColor"
            fill="transparent"
            strokeWidth={stroke}
            strokeDasharray={circumference + ' ' + circumference}
            style={{ strokeDashoffset }}
            strokeLinecap="round"
            className={colorClasses[activeColor as keyof typeof colorClasses]}
            r={normalizedRadius}
            cx={radius}
            cy={radius}
          />
        </svg>
        <div className={`absolute font-bold ${size === 'sm' ? 'text-xs' : size === 'md' ? 'text-xl' : 'text-3xl'}`}>
          {Math.round(score)}
        </div>
      </div>
      <p className={`text-slate-400 font-medium ${size === 'sm' ? 'text-[10px]' : 'text-sm'} uppercase tracking-wider`}>
        {label}
      </p>
    </div>
  );
};

export default ScoreDisplay;
