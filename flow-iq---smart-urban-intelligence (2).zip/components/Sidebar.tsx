
import React from 'react';
import { ModuleType } from '../types';

interface SidebarProps {
  activeModule: ModuleType;
  setActiveModule: (m: ModuleType) => void;
  location: string;
  onLocationReset: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeModule, setActiveModule, location, onLocationReset }) => {
  const menuItems = [
    { type: ModuleType.HOME, icon: 'fa-house', label: 'Dashboard' },
    { type: ModuleType.TRANSPORT, icon: 'fa-route', label: 'Transport IQ' },
    { type: ModuleType.LIVING, icon: 'fa-city', label: 'Living Analysis' },
    { type: ModuleType.INVESTMENT, icon: 'fa-chart-line', label: 'Investment' },
    { type: ModuleType.BUDGET, icon: 'fa-wallet', label: 'Travel Budget' },
    { type: ModuleType.COMMUTER, icon: 'fa-briefcase', label: 'Daily Commuter' },
    { type: ModuleType.RELOCATION, icon: 'fa-truck-ramp-box', label: 'Relocation' },
  ];

  return (
    <div className="w-full md:w-64 glass border-r border-indigo-500/20 flex flex-col">
      <div className="p-6 flex items-center gap-3">
        <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/30">
          <i className="fa-solid fa-bolt text-xl"></i>
        </div>
        <div>
          <h1 className="text-xl font-bold tracking-tight">Flow <span className="text-indigo-400">IQ</span></h1>
          <p className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">Urban Intelligence</p>
        </div>
      </div>

      <nav className="flex-1 px-4 py-2 space-y-1">
        {menuItems.map((item) => (
          <button
            key={item.type}
            onClick={() => setActiveModule(item.type)}
            className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all ${
              activeModule === item.type 
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
                : 'text-slate-400 hover:bg-white/5 hover:text-white'
            }`}
          >
            <i className={`fa-solid ${item.icon} w-5 text-center`}></i>
            <span className="font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-indigo-500/10">
        <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800">
          <p className="text-[10px] text-slate-500 uppercase font-bold mb-1">Current Focus</p>
          <p className="text-sm font-medium text-slate-200 truncate mb-3">{location}</p>
          <button 
            onClick={onLocationReset}
            className="w-full py-2 text-xs font-semibold text-indigo-400 bg-indigo-400/10 rounded-lg hover:bg-indigo-400/20 transition-colors"
          >
            Change Location
          </button>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
