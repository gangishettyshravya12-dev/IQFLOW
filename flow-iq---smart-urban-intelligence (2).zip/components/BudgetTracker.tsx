
import React, { useState } from 'react';
import { ModuleType, AnalysisResponse, BudgetInputs } from '../types';
import { analyzeUrbanData } from '../geminiService';
import AnalysisResult from './AnalysisResult';

interface BudgetTrackerProps {
  onResult: (score: number) => void;
}

const BudgetTracker: React.FC<BudgetTrackerProps> = ({ onResult }) => {
  const [inputs, setInputs] = useState<BudgetInputs>({
    mode: 'Car',
    distance: 10,
    costPerTrip: 20,
    fuelCostPerKm: 12,
    travelDays: 22,
    parking: 0,
    tolls: 0
  });
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<AnalysisResponse | null>(null);

  const calculateBudget = () => {
    let dailyCost = 0;
    if (inputs.mode === 'Car' || inputs.mode === 'Bike') {
      const fuelCost = (inputs.distance * 2) * (inputs.fuelCostPerKm || 0);
      dailyCost = fuelCost + inputs.parking + inputs.tolls;
    } else {
      dailyCost = (inputs.costPerTrip || 0) * 2;
    }

    const monthly = dailyCost * inputs.travelDays;
    const yearly = monthly * 12;
    const fiveYear = yearly * 5;

    return { monthly, yearly, fiveYear };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const calculated = calculateBudget();
    try {
      const result = await analyzeUrbanData('Budget Optimization', ModuleType.BUDGET, { ...inputs, calculated });
      setData(result);
      onResult(result.scores.overall);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const { monthly, yearly, fiveYear } = calculateBudget();

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-4 mb-2">
        <div className="w-12 h-12 rounded-full bg-indigo-600/20 flex items-center justify-center">
          <i className="fa-solid fa-wallet text-indigo-400"></i>
        </div>
        <div>
          <h2 className="text-2xl font-bold">Travel Budget IQ</h2>
          <p className="text-slate-400 text-sm">Optimize your urban commute spending</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 glass rounded-3xl p-8 border border-white/5 h-fit">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Transport Mode</label>
              <select 
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 focus:border-indigo-500 focus:outline-none"
                value={inputs.mode}
                onChange={(e) => setInputs({...inputs, mode: e.target.value as any})}
              >
                <option value="Car">Car</option>
                <option value="Bike">Bike</option>
                <option value="Metro">Metro</option>
                <option value="Bus">Bus</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">One-Way (km)</label>
                <input 
                  type="number"
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 focus:border-indigo-500 focus:outline-none"
                  value={inputs.distance}
                  onChange={(e) => setInputs({...inputs, distance: Number(e.target.value)})}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Travel Days</label>
                <input 
                  type="number"
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 focus:border-indigo-500 focus:outline-none"
                  value={inputs.travelDays}
                  onChange={(e) => setInputs({...inputs, travelDays: Number(e.target.value)})}
                />
              </div>
            </div>

            {['Car', 'Bike'].includes(inputs.mode) ? (
              <>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Fuel Cost per km (₹)</label>
                  <input 
                    type="number"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 focus:border-indigo-500 focus:outline-none"
                    value={inputs.fuelCostPerKm}
                    onChange={(e) => setInputs({...inputs, fuelCostPerKm: Number(e.target.value)})}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Parking (₹)</label>
                    <input 
                      type="number"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 focus:border-indigo-500 focus:outline-none"
                      value={inputs.parking}
                      onChange={(e) => setInputs({...inputs, parking: Number(e.target.value)})}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Tolls (₹)</label>
                    <input 
                      type="number"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 focus:border-indigo-500 focus:outline-none"
                      value={inputs.tolls}
                      onChange={(e) => setInputs({...inputs, tolls: Number(e.target.value)})}
                    />
                  </div>
                </div>
              </>
            ) : (
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Cost Per Trip (₹)</label>
                <input 
                  type="number"
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 focus:border-indigo-500 focus:outline-none"
                  value={inputs.costPerTrip}
                  onChange={(e) => setInputs({...inputs, costPerTrip: Number(e.target.value)})}
                />
              </div>
            )}

            <button 
              disabled={loading}
              className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-2xl transition-all shadow-lg shadow-indigo-500/25 flex items-center justify-center gap-2"
            >
              {loading ? <i className="fa-solid fa-circle-notch animate-spin"></i> : <i className="fa-solid fa-calculator"></i>}
              Analyze Expenses
            </button>
          </form>
        </div>

        <div className="lg:col-span-2 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="glass rounded-3xl p-6 border border-white/5 text-center">
              <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest mb-1">Monthly Spending</p>
              <h3 className="text-3xl font-bold text-indigo-400">₹{Math.round(monthly).toLocaleString()}</h3>
            </div>
            <div className="glass rounded-3xl p-6 border border-white/5 text-center">
              <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest mb-1">Yearly Projection</p>
              <h3 className="text-3xl font-bold text-emerald-400">₹{Math.round(yearly).toLocaleString()}</h3>
            </div>
            <div className="glass rounded-3xl p-6 border border-white/5 text-center bg-indigo-500/5">
              <p className="text-[10px] text-indigo-300 uppercase font-bold tracking-widest mb-1">5-Year Saving Potential</p>
              <h3 className="text-3xl font-bold text-white">₹{Math.round(fiveYear).toLocaleString()}</h3>
            </div>
          </div>

          {data && <AnalysisResult data={data} title="Cost Optimization Intelligence" />}
        </div>
      </div>
    </div>
  );
};

export default BudgetTracker;
