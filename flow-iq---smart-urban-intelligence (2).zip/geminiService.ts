
import { GoogleGenAI, Type } from "@google/genai";
import { ModuleType, AnalysisResponse } from "./types";

/**
 * Initializing Google GenAI with the API key from environment variables.
 * Following strict initialization guidelines for @google/genai.
 */
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const ANALYSIS_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    scores: {
      type: Type.OBJECT,
      properties: {
        commute: { type: Type.NUMBER },
        costEfficiency: { type: Type.NUMBER },
        lifestyle: { type: Type.NUMBER },
        growthPotential: { type: Type.NUMBER },
        stressImpact: { type: Type.NUMBER },
        livingStability: { type: Type.NUMBER },
        safety: { type: Type.NUMBER },
        productivity: { type: Type.NUMBER },
        overall: { type: Type.NUMBER },
      },
      required: ['commute', 'costEfficiency', 'lifestyle', 'growthPotential', 'stressImpact', 'livingStability', 'safety', 'productivity', 'overall'],
    },
    insights: {
      type: Type.OBJECT,
      properties: {
        strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
        weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
        suggestions: { type: Type.ARRAY, items: { type: Type.STRING } },
        decisionLabel: { type: Type.STRING, description: "One of: Excellent, Good, Moderate, Needs Improvement" },
      },
      required: ['strengths', 'weaknesses', 'suggestions', 'decisionLabel'],
    },
    details: {
      type: Type.OBJECT,
      properties: {
        secondaryScores: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              label: { type: Type.STRING },
              value: { type: Type.NUMBER }
            }
          }
        }
      },
      description: "Additional module-specific data",
    }
  },
  required: ['scores', 'insights', 'details'],
};

export const analyzeUrbanData = async (location: string, module: ModuleType, extraData?: any): Promise<AnalysisResponse> => {
  const prompt = `
    Perform a comprehensive Urban Intelligence Analysis for the following location: "${location}".
    Analysis Module: ${module}.
    Additional Context: ${JSON.stringify(extraData || {})}
    
    CRITICAL: Provide scores from 0-100. Use Indian Context where applicable (Rupees ₹, local transport like Metro/Bus/Autos).
    Ensure the data reflects realistic urban dynamics for that specific area.
    
    Specific Module Requirements:
    - TRANSPORT: Road vs Metro vs Bus analysis, traffic simulations, peak hour alerts.
    - LIVING: Safety, Pollution (AQI), Lifestyle, Stability, Walkability.
    - INVESTMENT: Real estate ROI, infrastructure expansion, affordability.
    - BUDGET: 5-year projections based on travel inputs.
    - COMMUTER: Time-life balance and productivity impacts.
    - RELOCATION: Comparison of locations.
  `;

  // Use Google Search grounding for real-world urban data accuracy.
  // Using 'gemini-3-pro-preview' for complex reasoning and ROI projections.
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: ANALYSIS_SCHEMA,
      tools: [{ googleSearch: {} }]
    },
  });

  try {
    const jsonStr = response.text || '{}';
    const result = JSON.parse(jsonStr);

    // Always extract website URLs from groundingChunks when using Google Search grounding
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
      title: chunk.web?.title || 'Urban Insight Source',
      uri: chunk.web?.uri
    })).filter((s: any) => s.uri) || [];

    return { ...result, sources };
  } catch (e) {
    console.error("Failed to parse Gemini response", e);
    throw new Error("Intelligence engine returned malformed data.");
  }
};
