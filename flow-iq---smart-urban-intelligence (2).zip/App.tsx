
import React, { useState, useEffect } from 'react';
import { ModuleType, HistoryItem } from './types';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import LocationInput from './components/LocationInput';
import TransportAnalysis from './components/TransportAnalysis';
import LivingAnalysis from './components/LivingAnalysis';
import InvestmentAnalysis from './components/InvestmentAnalysis';
import BudgetTracker from './components/BudgetTracker';
import CommuterMode from './components/CommuterMode';
import RelocationSimulator from './components/RelocationSimulator';
import Dashboard from './components/Dashboard';

const App: React.FC = () => {
  const [location, setLocation] = useState<string | null>(null);
  const [activeModule, setActiveModule] = useState<ModuleType>(ModuleType.HOME);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [currency, setCurrency] = useState('INR');

  useEffect(() => {
    const savedHistory = localStorage.getItem('flow_iq_history');
    if (savedHistory) setHistory(JSON.parse(savedHistory));
  }, []);

  const addToHistory = (module: ModuleType, loc: string, score: number) => {
    const newItem: HistoryItem = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
      location: loc,
      module,
      overallScore: score
    };
    const updated = [newItem, ...history].slice(0, 20);
    setHistory(updated);
    localStorage.setItem('flow_iq_history', JSON.stringify(updated));
  };

  if (!location) {
    return <LocationInput onLocationSet={setLocation} />;
  }

  const renderModule = () => {
    switch (activeModule) {
      case ModuleType.HOME:
        return <Dashboard location={location} history={history} onModuleSwitch={setActiveModule} />;
      case ModuleType.TRANSPORT:
        return <TransportAnalysis location={location} onResult={(s) => addToHistory(ModuleType.TRANSPORT, location, s)} />;
      case ModuleType.LIVING:
        return <LivingAnalysis location={location} onResult={(s) => addToHistory(ModuleType.LIVING, location, s)} />;
      case ModuleType.INVESTMENT:
        return <InvestmentAnalysis location={location} onResult={(s) => addToHistory(ModuleType.INVESTMENT, location, s)} />;
      case ModuleType.BUDGET:
        return <BudgetTracker onResult={(s) => addToHistory(ModuleType.BUDGET, location, s)} />;
      case ModuleType.COMMUTER:
        return <CommuterMode location={location} onResult={(s) => addToHistory(ModuleType.COMMUTER, location, s)} />;
      case ModuleType.RELOCATION:
        return <RelocationSimulator currentLocation={location} onResult={(s) => addToHistory(ModuleType.RELOCATION, location, s)} />;
      default:
        return <Dashboard location={location} history={history} onModuleSwitch={setActiveModule} />;
    }
  };

  return (
    <div className="flex flex-col md:flex-row h-screen overflow-hidden">
      <Sidebar 
        activeModule={activeModule} 
        setActiveModule={setActiveModule} 
        location={location} 
        onLocationReset={() => setLocation(null)} 
      />
      
      <div className="flex-1 flex flex-col min-w-0">
        <Header 
          location={location} 
          currency={currency} 
          setCurrency={setCurrency} 
          activeModule={activeModule}
        />
        
        <main className="flex-1 overflow-y-auto p-4 md:p-8 bg-slate-950/50">
          <div className="max-w-7xl mx-auto">
            {renderModule()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;
