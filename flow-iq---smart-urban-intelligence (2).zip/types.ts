
export enum ModuleType {
  HOME = 'HOME',
  TRANSPORT = 'TRANSPORT',
  LIVING = 'LIVING',
  INVESTMENT = 'INVESTMENT',
  BUDGET = 'BUDGET',
  COMMUTER = 'COMMUTER',
  RELOCATION = 'RELOCATION'
}

export interface UrbanScores {
  commute: number;
  costEfficiency: number;
  lifestyle: number;
  growthPotential: number;
  stressImpact: number;
  livingStability: number;
  safety: number;
  productivity: number;
  overall: number;
}

export interface AnalysisResponse {
  scores: UrbanScores;
  insights: {
    strengths: string[];
    weaknesses: string[];
    suggestions: string[];
    decisionLabel: 'Excellent' | 'Good' | 'Moderate' | 'Needs Improvement';
  };
  details: {
    secondaryScores?: Array<{ label: string; value: number }>;
    projections?: any;
    comparisons?: any;
    [key: string]: any;
  };
  sources?: Array<{ title: string; uri: string }>;
}

export interface BudgetInputs {
  mode: 'Car' | 'Metro' | 'Bus' | 'Bike';
  distance: number;
  costPerTrip?: number;
  fuelCostPerKm?: number;
  travelDays: number;
  parking: number;
  tolls: number;
}

export interface HistoryItem {
  id: string;
  timestamp: number;
  location: string;
  module: ModuleType;
  overallScore: number;
}
